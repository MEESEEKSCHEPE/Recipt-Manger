import React, { useState } from "react";
import { db, storage } from "../firebase"; // Ajusta la ruta según donde se encuentre tu archivo de configuración de Firebase
import { collection, addDoc } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { Container, Typography, TextField, Button, Box } from "@mui/material";

const RecipeForm = () => {
  const [title, setTitle] = useState("");
  const [ingredients, setIngredients] = useState("");
  const [instructions, setInstructions] = useState("");
  const [image, setImage] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleImageChange = (e) => {
    if (e.target.files[0]) {
      setImage(e.target.files[0]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    if (!title || !ingredients || !instructions) {
      setError("Todos los campos son obligatorios");
      setLoading(false);
      return;
    }

    try {
      let imageUrl = "";

      // Si hay imagen, subirla a Firebase Storage
      if (image) {
        const imageRef = ref(storage, `recipes/${image.name}`);
        await uploadBytes(imageRef, image);
        imageUrl = await getDownloadURL(imageRef);
      }

      // Guardar la receta en Firestore
      await addDoc(collection(db, "recipes"), {
        title,
        ingredients,
        instructions,
        imageUrl,
        createdAt: new Date(),
      });

      // Limpiar formulario
      setTitle("");
      setIngredients("");
      setInstructions("");
      setImage(null);
    } catch (err) {
      setError("Error al guardar la receta: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="sm">
      <Box
        sx={{
          mt: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Typography variant="h4" gutterBottom>
          Agregar Receta
        </Typography>
        <form onSubmit={handleSubmit} style={{ width: "100%" }}>
          <TextField
            label="Título"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            fullWidth
            margin="normal"
            required
          />
          <TextField
            label="Ingredientes"
            value={ingredients}
            onChange={(e) => setIngredients(e.target.value)}
            fullWidth
            multiline
            rows={3}
            margin="normal"
            required
          />
          <TextField
            label="Instrucciones"
            value={instructions}
            onChange={(e) => setInstructions(e.target.value)}
            fullWidth
            multiline
            rows={4}
            margin="normal"
            required
          />
          <input
            type="file"
            onChange={handleImageChange}
            accept="image/*"
            style={{ marginTop: "10px" }}
          />
          <Button
            type="submit"
            variant="contained"
            color="primary"
            fullWidth
            sx={{ mt: 2 }}
            disabled={loading}
          >
            {loading ? "Guardando..." : "Agregar Receta"}
          </Button>
        </form>
        {error && (
          <Typography color="error" sx={{ mt: 1 }}>
            {error}
          </Typography>
        )}
      </Box>
    </Container>
  );
};

export default RecipeForm;
