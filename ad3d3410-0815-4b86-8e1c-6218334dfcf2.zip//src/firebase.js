// Import the necessary functions from Firebase SDK
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore"; // Para Firestore
import { getStorage } from "firebase/storage"; // Para Storage
import { getAnalytics } from "firebase/analytics";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyD8lh0mCuZg3wWC9pLXvbDWGhbSxITBBrs",
  authDomain: "recipe-manager-3b798.firebaseapp.com",
  projectId: "recipe-manager-3b798",
  storageBucket: "recipe-manager-3b798.firebasestorage.app",
  messagingSenderId: "173049705889",
  appId: "1:173049705889:web:0b74eba5521a5dce8547e0",
  measurementId: "G-51XBK9B8J0",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Inicializar Firestore y Storage
const db = getFirestore(app); // Firestore
const storage = getStorage(app); // Storage

// Opcional: inicializar Analytics si lo necesitas
const analytics = getAnalytics(app);

// Exporta db y storage para usarlos en otros archivos
export { db, storage };
